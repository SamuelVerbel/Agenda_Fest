import org.json.JSONObject;

public class Afiche {
    
    private int codigo;
    private String titulo;
    private String descripcion;
    private String patrocinador;
    private String fechaPublicacion;
    private String costo;
    private String rutaImagen;

    // Constructor con ID (para cargar/actualizar)
    public Afiche(int codigo, String titulo, String descripcion, String patrocinador,
                  String fechaPublicacion, String costo, String rutaImagen) {
        this.codigo = codigo;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.patrocinador = patrocinador;
        this.fechaPublicacion = fechaPublicacion;
        this.costo = costo;
        this.rutaImagen = rutaImagen;
    }

    // Constructor sin ID (para crear nuevos afiches)
    public Afiche(String titulo, String descripcion, String patrocinador,
                  String fechaPublicacion, String costo, String rutaImagen) {
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.patrocinador = patrocinador;
        this.fechaPublicacion = fechaPublicacion;
        this.costo = costo;
        this.rutaImagen = rutaImagen;
    }

    // Getter y Setter para codigo
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    // Getter y Setter para titulo
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    // Getter y Setter para descripcion
    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    // Getter y Setter para patrocinador
    public String getPatrocinador() {
        return patrocinador;
    }

    public void setPatrocinador(String patrocinador) {
        this.patrocinador = patrocinador;
    }

    // Getter y Setter para fechaPublicacion
    public String getFechaPublicacion() {
        return fechaPublicacion;
    }

    public void setFechaPublicacion(String fechaPublicacion) {
        this.fechaPublicacion = fechaPublicacion;
    }

    // Getter y Setter para costo
    public String getCosto() {
        return costo;
    }

    public void setCosto(String costo) {
        this.costo = costo;
    }

    // Getter y Setter para rutaImagen
    public String getRutaImagen() {
        return rutaImagen;
    }

    public void setRutaImagen(String rutaImagen) {
        this.rutaImagen = rutaImagen;
    }

    // Convertir a JSON
    public JSONObject toJSON() {
        JSONObject o = new JSONObject();
        o.put("codigo", codigo);
        o.put("titulo", titulo);
        o.put("descripcion", descripcion);
        o.put("patrocinador", patrocinador);
        o.put("fechaPublicacion", fechaPublicacion);
        o.put("costo", costo);
        o.put("rutaImagen", rutaImagen);
        return o;
    }

    // Crear Afiche desde JSON
    public static Afiche fromJSON(JSONObject o) {
        return new Afiche(
            o.optInt("codigo", 0),
            o.optString("titulo", ""),
            o.optString("descripcion", ""),
            o.optString("patrocinador", ""),
            o.optString("fechaPublicacion", ""),
            o.optString("costo", ""),
            o.optString("rutaImagen", "")
        );
    }
}