import org.json.JSONObject;
 
public class Patrocinador {
    
    private int codigo;
    private String nombre;
    private String tipo;
    private String telefono;
    
      // Constructor con ID (para cargar/actualizar)
    public Patrocinador(int codigo, String nombre, String tipo, String telefono) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.tipo = tipo;
        this.telefono = telefono;
        
    }

    // Constructor sin ID (para crear nuevos representantes)
    public Patrocinador(String nombre, String tipo, String telefono) {
        this.nombre = nombre;
        this.tipo = tipo ;
        this.telefono = telefono;
      
    }
    
    // Getter y Setter para codigo
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    // Getter y Setter para nombre
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // Getter y Setter para tipo
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    // Getter y Setter para telefono
    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    
    // Convertir a JSON
    public JSONObject toJSON() {
        JSONObject o = new JSONObject();
        o.put("codigo", codigo);
        o.put("nombre", nombre);
        o.put("tipo", tipo);
        o.put("telefono", telefono);
        return o;
    }

    // Crear Representante desde JSON
    public static Patrocinador fromJSON(JSONObject o) {
        return new Patrocinador(
            o.optInt("codigo", 0),
            o.optString("nombre", ""),
            o.optString("tipo", ""),
            o.optString("telefono", "")
        );
    }
}


