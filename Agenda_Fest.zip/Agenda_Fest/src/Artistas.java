import java.awt.Component;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import org.json.JSONArray;
import org.json.JSONObject;

public class Artistas extends javax.swing.JFrame {
    private JSONDataManager manager; 

    public Artistas() {
        initComponents();
        manager = new JSONDataManager<>("artistas.json", Artista.class);
        loadTable();     
        ajustarColumnas(tabla_artista);
    }
    
    public void ajustarColumnas(JTable table) {
        for (int column = 0; column < table.getColumnCount(); column++) {
            TableColumn col = table.getColumnModel().getColumn(column);
            int width = 50; // ancho mínimo
            for (int row = 0; row < table.getRowCount(); row++) {
                TableCellRenderer renderer = table.getCellRenderer(row, column);
                Component comp = table.prepareRenderer(renderer, row, column);
                width = Math.max(comp.getPreferredSize().width + 10, width);
            }
            col.setPreferredWidth(width);
        }
    }

    
    private void loadTable() {
        String[] cols = {"ID","Nombre","Teléfono","genero","Email","Descripción"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };

        JSONArray arr = manager.findAll();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            Object[] row = {
                o.optInt("id", 0),
                o.optString("nombre", ""),
                o.optString("telefono", ""),
                o.optString("genero", ""),
                o.optString("email", ""),
                o.optString("descripcion", "")
            };
            model.addRow(row);
        }

        tabla_artista.setModel(model);
        tabla_artista.getColumnModel().getColumn(0).setPreferredWidth(40);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnRegresar1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla_artista = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(249, 140, 32));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("AgendaFest 2025");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Fiestas Novembrinas Cartagena de Indias ");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText(" Gestión de Artistas ");

        btnRegresar1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnRegresar1.setText("Regresar");
        btnRegresar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRegresar1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(102, 102, 102)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 159, Short.MAX_VALUE)
                .addComponent(btnRegresar1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(208, 208, 208))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnRegresar1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 850, 100));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 829, 877, -1));

        tabla_artista.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Nombre", "Teléfono", "Género", "Email", "Descripción"
            }
        ));
        tabla_artista.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabla_artistaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabla_artista);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 850, 330));

        jButton1.setBackground(new java.awt.Color(204, 255, 204));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setText("Eliminar Artista");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 130, -1, -1));

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel11.setText("Lista de Artistas");
        getContentPane().add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, -1, -1));

        jButton2.setBackground(new java.awt.Color(204, 255, 204));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setText("Editar Artista");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 130, -1, -1));

        jButton3.setBackground(new java.awt.Color(204, 255, 204));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton3.setText("Nuevo Artista");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 130, -1, 30));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegresar1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRegresar1MouseClicked
        Pag_Principal Pag_Principal = new Pag_Principal();
        Pag_Principal.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnRegresar1MouseClicked

    private void tabla_artistaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabla_artistaMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tabla_artistaMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        int row = tabla_artista.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Seleccione un artista"); return; }
        int id = (int) tabla_artista.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "¿Eliminar artista ID " + id + "?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (manager.delete(id)) {
                JOptionPane.showMessageDialog(this, "Artista eliminado");
                loadTable();
            } else {
                JOptionPane.showMessageDialog(this, "Error al eliminar artista");
            }
        }
    }//GEN-LAST:event_jButton1ActionPerformed
// editar artista
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        int row = tabla_artista.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Seleccione un artista"); return; }

        int id = (int) tabla_artista.getValueAt(row, 0);

        // Recuperar como Artista, no JSONObject
        Artista a = (Artista) manager.findById(id);  
        Artista edit = showArtistForm(a);

    if (edit != null) {
            if (manager.update(id, edit)) {   // 🔥 ya no .toJSON()
                JOptionPane.showMessageDialog(this, "Artista actualizado");
                loadTable();
            } else {
                JOptionPane.showMessageDialog(this, "Error al actualizar artista");
            }
        }
    }//GEN-LAST:event_jButton2ActionPerformed
// nuevo artista
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
         Artista nuevo = showArtistForm(null);
            if (nuevo != null) {
                nuevo.setId(manager.getNextId()); // asignar ID
            if (manager.add(nuevo)) {   // 🔥 ya no .toJSON()
                JOptionPane.showMessageDialog(this, "Artista creado");
                    loadTable();
            } else {
                JOptionPane.showMessageDialog(this, "Error al crear artista");
            }
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Artistas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnRegresar1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabla_artista;
    // End of variables declaration//GEN-END:variables

    private Artista showArtistForm(Artista artista) {
        // Crear un diálogo para ingresar datos del artista
        JPanel panel = new JPanel(new GridLayout(6, 2));

        JTextField nombreField = new JTextField(20);
        JTextField telefonoField = new JTextField(20);
        JTextField tipoField = new JTextField(20);
        JTextField emailField = new JTextField(20);
        JTextArea descripcionArea = new JTextArea(3, 20);
        JScrollPane descScroll = new JScrollPane(descripcionArea);

        // Si estamos editando, llenar los campos
        if (artista != null) {
            nombreField.setText(artista.getNombre());
            telefonoField.setText(artista.getTelefono());
            tipoField.setText(artista.getGenero());
            emailField.setText(artista.getEmail());
            descripcionArea.setText(artista.getDescripcion());
        }

        panel.add(new JLabel("Nombre:"));
        panel.add(nombreField);
        panel.add(new JLabel("Teléfono:"));
        panel.add(telefonoField);
        panel.add(new JLabel("Género:"));
        panel.add(tipoField);
        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Descripción:"));
        panel.add(descScroll);

        int result = JOptionPane.showConfirmDialog(this, panel, 
            artista != null ? "Editar Artista" : "Nuevo Artista", 
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String nombre = nombreField.getText().trim();
            String telefono = telefonoField.getText().trim();
            String genero = tipoField.getText().trim();
            String email = emailField.getText().trim();
            String descripcion = descripcionArea.getText().trim();

            if (nombre.isEmpty() || telefono.isEmpty() || genero.isEmpty() || email.isEmpty() || descripcion.isEmpty()) {
                JOptionPane.showMessageDialog(this, " Es obligatorio llenar todos los campos ");
                return null;
            }

            int id = artista != null ? artista.getId() : 0;
            return new Artista(id, nombre, telefono, genero, email, descripcion);
        }

        return null;
    }
}
