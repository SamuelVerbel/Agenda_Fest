import org.json.JSONObject;

public class Lugar {
    private int codigo_lugar;
    private String nombre_lugar;
    private String capacidad_lugar;
    private String direccion_lugar;
    private String tipo_lugar;

    // Constructor con código (para cargar/actualizar)
    public Lugar(int codigo_lugar, String nombre_lugar, String capacidad_lugar, String direccion_lugar, String tipo_lugar) {
        this.codigo_lugar = codigo_lugar;
        this.nombre_lugar = nombre_lugar;
        this.capacidad_lugar = capacidad_lugar;
        this.direccion_lugar = direccion_lugar;
        this.tipo_lugar = tipo_lugar;
    }

    // Constructor sin código (para crear nuevos lugares)
    public Lugar(String nombre_lugar, String capacidad_lugar, String direccion_lugar, String tipo_lugar) {
        this.nombre_lugar = nombre_lugar;
        this.capacidad_lugar = capacidad_lugar;
        this.direccion_lugar = direccion_lugar;
        this.tipo_lugar = tipo_lugar;
    }

    // Getters y Setters
    public int getCodigo_lugar() {
        return codigo_lugar;
    }

    public void setCodigo_lugar(int codigo_lugar) {
        this.codigo_lugar = codigo_lugar;
    }

    public String getNombre_lugar() {
        return nombre_lugar;
    }

    public void setNombre_lugar(String nombre_lugar) {
        this.nombre_lugar = nombre_lugar;
    }

    public String getCapacidad_lugar() {
        return capacidad_lugar;
    }

    public void setCapacidad_lugar(String capacidad_lugar) {
        this.capacidad_lugar = capacidad_lugar;
    }

    public String getDireccion_lugar() {
        return direccion_lugar;
    }

    public void setDireccion_lugar(String direccion_lugar) {
        this.direccion_lugar = direccion_lugar;
    }

    public String getTipo_lugar() {
        return tipo_lugar;
    }

    public void setTipo_lugar(String tipo_lugar) {
        this.tipo_lugar = tipo_lugar;
    }

    // Convertir a JSON
    public JSONObject toJSON() {
        JSONObject o = new JSONObject();
        o.put("codigo_lugar", codigo_lugar);
        o.put("nombre_lugar", nombre_lugar);
        o.put("capacidad_lugar", capacidad_lugar);
        o.put("direccion_lugar", direccion_lugar);
        o.put("tipo_lugar", tipo_lugar);
        return o;
    }

    // Crear Lugar desde JSON
    public static Lugar fromJSON(JSONObject o) {
        return new Lugar(
            o.optInt("codigo_lugar", 0),
            o.optString("nombre_lugar", ""),
            o.optString("capacidad_lugar", ""),
            o.optString("direccion_lugar", ""),
            o.optString("tipo_lugar", "")
        );
    }
}
