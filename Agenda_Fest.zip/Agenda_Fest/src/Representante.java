import org.json.JSONObject;

public class Representante {
    private int id;
    private String nombre;
    private String apellido;
    private String telefono;
    private String email;

    // Constructor con ID (para cargar/actualizar)
    public Representante(int id, String nombre, String apellido, String telefono, String email) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.email = email;
    }

    // Constructor sin ID (para crear nuevos representantes)
    public Representante(String nombre, String apellido, String telefono, String email) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.email = email;
    }

    // Getters y Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Convertir a JSON
    public JSONObject toJSON() {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("nombre", nombre);
        o.put("apellido", apellido);
        o.put("telefono", telefono);
        o.put("email", email);
        return o;
    }

    // Crear Representante desde JSON
    public static Representante fromJSON(JSONObject o) {
        return new Representante(
            o.optInt("id", 0),
            o.optString("nombre", ""),
            o.optString("apellido", ""),
            o.optString("telefono", ""),
            o.optString("email", "")
        );
    }
}
