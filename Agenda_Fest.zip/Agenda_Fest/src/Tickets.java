import java.awt.Component;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
//import javax.swing.JScrollPane;
import javax.swing.JTable;
//import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import org.json.JSONArray;
import org.json.JSONObject;

public class Tickets extends javax.swing.JFrame {
    private JSONDataManager manager;
    
    public Tickets() {
        initComponents();
        manager = new JSONDataManager<>("tickets.json", Ticket.class);
        loadTable();     
        ajustarColumnas(tabla_tickets);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btnRegresar1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla_tickets = new javax.swing.JTable();
        btnDelTicket = new javax.swing.JButton();
        btnEditTicket = new javax.swing.JButton();
        btnNewTicket = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));

        jPanel4.setBackground(new java.awt.Color(249, 140, 32));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("AgendaFest 2025");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Fiestas Novembrinas Cartagena de Indias ");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText(" Gestión de Tickets");

        btnRegresar1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnRegresar1.setText("Regresar");
        btnRegresar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRegresar1MouseClicked(evt);
            }
        });
        btnRegresar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegresar1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(82, 82, 82)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 179, Short.MAX_VALUE)
                .addComponent(btnRegresar1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(286, 286, 286)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(btnRegresar1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addComponent(jLabel5))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        tabla_tickets.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Tipo", "Precio", "Evento"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, true, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tabla_tickets);

        btnDelTicket.setBackground(new java.awt.Color(204, 255, 204));
        btnDelTicket.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnDelTicket.setText("Eliminar Ticket");
        btnDelTicket.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelTicketActionPerformed(evt);
            }
        });

        btnEditTicket.setBackground(new java.awt.Color(204, 255, 204));
        btnEditTicket.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnEditTicket.setText("Editar Ticket");
        btnEditTicket.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditTicketActionPerformed(evt);
            }
        });

        btnNewTicket.setBackground(new java.awt.Color(204, 255, 204));
        btnNewTicket.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnNewTicket.setText("Nuevo Ticket");
        btnNewTicket.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewTicketActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel11.setText("Lista de Tickets");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(79, 79, 79)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnNewTicket)
                .addGap(28, 28, 28)
                .addComponent(btnEditTicket)
                .addGap(33, 33, 33)
                .addComponent(btnDelTicket)
                .addGap(43, 43, 43))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnNewTicket, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEditTicket)
                    .addComponent(btnDelTicket)
                    .addComponent(jLabel11))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(245, 245, 245))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, -1, 460));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegresar1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRegresar1MouseClicked
        Pag_Principal Pag_Principal = new Pag_Principal();
        Pag_Principal.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnRegresar1MouseClicked
    
    public void ajustarColumnas(JTable table) {
        for (int column = 0; column < table.getColumnCount(); column++) {
            TableColumn col = table.getColumnModel().getColumn(column);
            int width = 50; // ancho mínimo
            for (int row = 0; row < table.getRowCount(); row++) {
                TableCellRenderer renderer = table.getCellRenderer(row, column);
                Component comp = table.prepareRenderer(renderer, row, column);
                width = Math.max(comp.getPreferredSize().width + 10, width);
            }
            col.setPreferredWidth(width);
        }
    }
    
    private void loadTable() {
        String[] cols = {"codigo","tipo","precio","evento"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };

        JSONArray arr = manager.findAll();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            Object[] row = {
                o.optInt("codigo", 0),
                o.optString("tipo", ""),
                o.optString("precio", ""),
                o.optString("evento", "")
            };
            model.addRow(row);
        }

        tabla_tickets.setModel(model);
        tabla_tickets.getColumnModel().getColumn(0).setPreferredWidth(40);
    }
    
    
    private void btnRegresar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegresar1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnRegresar1ActionPerformed

    private void btnDelTicketActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelTicketActionPerformed
        int row = tabla_tickets.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Seleccione un ticket"); return; }
        int id = (int) tabla_tickets.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "¿Eliminar ticket 'codigo' " + id + "?", " Confirmar ", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (manager.delete(id)) {
                JOptionPane.showMessageDialog(this, " Ticket Eliminado");
                loadTable();
            } else {
                JOptionPane.showMessageDialog(this, " Error al eliminar el ticket ");
            }
        }
    }//GEN-LAST:event_btnDelTicketActionPerformed

    private void btnEditTicketActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditTicketActionPerformed
        int row = tabla_tickets.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Seleccione un ticket"); return; }

        int id = (int) tabla_tickets.getValueAt(row, 0);

        // Recuperar como Artista, no JSONObject
        Ticket t = (Ticket) manager.findById(id);
        Ticket edit = showTicketForm(t);

        if (edit != null) {
            if (manager.update(id, edit)) {   // 🔥 ya no .toJSON()
                JOptionPane.showMessageDialog(this, "Ticket actualizado");
                loadTable();
            } else {
                JOptionPane.showMessageDialog(this, "Error al actualizar el ticket");
            }
        }
    }//GEN-LAST:event_btnEditTicketActionPerformed

    private void btnNewTicketActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewTicketActionPerformed
        Ticket nuevo = showTicketForm(null);
        if (nuevo != null) {
            nuevo.setCodigo(manager.getNextId()); // asignar ID
            if (manager.add(nuevo)) {   // 🔥 ya no .toJSON()
                JOptionPane.showMessageDialog(this, "Ticket creado");
                loadTable();
            } else {
                JOptionPane.showMessageDialog(this, "Error al crear Ticket");
            }
        }
    }//GEN-LAST:event_btnNewTicketActionPerformed
    
    
    private Ticket showTicketForm(Ticket ticket) {
        JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10)); // 4 campos, 2 columnas, con espacio entre celdas

        JTextField tipoField = new JTextField(20);
        JTextField precioField = new JTextField(20);
        JTextField eventoField = new JTextField(20);

        // Si estamos editando, llenar los campos
        if (ticket != null) {
            tipoField.setText(ticket.getTipo());
            precioField.setText(ticket.getPrecio());
            eventoField.setText(ticket.getEvento());
        }

        // Agregar campos al panel
        panel.add(new JLabel("Tipo:"));
        panel.add(tipoField);
        panel.add(new JLabel("Precio:"));
        panel.add(precioField);
        panel.add(new JLabel("Evento:"));
        panel.add(eventoField);

        int result = JOptionPane.showConfirmDialog(this, panel,
            ticket != null ? "Editar Ticket" : "Nuevo Ticket",
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String tipo = tipoField.getText().trim();
            String precio = precioField.getText().trim();
            String evento = eventoField.getText().trim();

            if (tipo.isEmpty() || precio.isEmpty() || evento.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ningún campo puede estar vacío.");
                return null;
            }
            int codigo = ticket != null ? ticket.getCodigo() : 0;
            return new Ticket(codigo, tipo, precio, evento);
        }
        return null;
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Tickets.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Tickets.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Tickets.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Tickets.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Tickets().setVisible(true);
            }
        });                                                            
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDelTicket;
    private javax.swing.JButton btnEditTicket;
    private javax.swing.JButton btnNewTicket;
    private javax.swing.JButton btnRegresar1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabla_tickets;
    // End of variables declaration//GEN-END:variables
}
