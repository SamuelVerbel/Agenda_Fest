import org.json.JSONObject;

class Artista {
    private int id;
    private String nombre;
    private String telefono;
    private String genero;
    private String email;
    private String descripcion;

    // 🔹 Constructor sin ID (para nuevos artistas)
    public Artista(String nombre, String telefono, String genero, String email, String descripcion) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.genero = genero;
        this.email = email;
        this.descripcion = descripcion;
    }

    // 🔹 Constructor con ID (para cargar desde JSON o actualizar)
    public Artista(int id, String nombre, String telefono, String genero, String email, String descripcion) {
        this.id = id;
        this.nombre = nombre;
        this.telefono = telefono;
        this.genero = genero;
        this.email = email;
        this.descripcion = descripcion;
    }

    // Getters
    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getTelefono() { return telefono; }
    public String getGenero() { return genero; }
    public String getEmail() { return email; }
    public String getDescripcion() { return descripcion; }

    // Setters
    public void setId(int id) { this.id = id; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    public void setGenero(String genero) { this.genero = genero; }
    public void setEmail(String email) { this.email = email; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    // 🔥 Convertir a JSON
    public JSONObject toJSON() {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("nombre", nombre);
        o.put("telefono", telefono);
        o.put("genero", genero);
        o.put("email", email);
        o.put("descripcion", descripcion);
        return o;
    }

    // 🔥 Crear Artista desde JSON
    public static Artista fromJSON(JSONObject o) {
        return new Artista(
            o.optInt("id", 0),
            o.optString("nombre", ""),
            o.optString("telefono", ""),
            o.optString("genero", ""),
            o.optString("email", ""),
            o.optString("descripcion", "")
        );
    }
}