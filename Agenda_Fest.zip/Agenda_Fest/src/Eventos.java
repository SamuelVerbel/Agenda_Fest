import java.awt.Component;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import org.json.JSONArray;
import org.json.JSONObject;

public class Eventos extends javax.swing.JFrame {
    private JSONDataManager manager; 

    public Eventos() {
        initComponents();
        manager = new JSONDataManager<>("eventos.json", Evento.class);
        loadTable();     
        ajustarColumnas(tabla_eventos);
    }
    
    public void ajustarColumnas(JTable table) {
        for (int column = 0; column < table.getColumnCount(); column++) {
            TableColumn col = table.getColumnModel().getColumn(column);
            int width = 50; // ancho mínimo
            for (int row = 0; row < table.getRowCount(); row++) {
                TableCellRenderer renderer = table.getCellRenderer(row, column);
                Component comp = table.prepareRenderer(renderer, row, column);
                width = Math.max(comp.getPreferredSize().width + 10, width);
            }
            col.setPreferredWidth(width);
        }
    }
    
    private void loadTable() {
        String[] cols = {"codigo","lugar","representante","nombre","descripcion","tematica", "tipo", "fecha_inicio", "fecha_fin"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };

        JSONArray arr = manager.findAll();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            Object[] row = {
                o.optInt("codigo", 0),
                o.optString("lugar", ""),
                o.optString("representante", ""),
                o.optString("nombre", ""),
                o.optString("descripcion", ""),
                o.optString("tematica", ""),
                o.optString("tipo", ""),
                o.optString("fecha_inicio", ""),
                o.optString("fecha_fin", "")
            };
            model.addRow(row);
        }

        tabla_eventos.setModel(model);
        tabla_eventos.getColumnModel().getColumn(0).setPreferredWidth(40);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel9 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        btnRegresar6 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel22 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla_eventos = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel9.setBackground(new java.awt.Color(249, 140, 32));

        jLabel19.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("AgendaFest 2025");

        jLabel20.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Fiestas Novembrinas Cartagena de Indias ");

        jLabel21.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText(" Gestión de Eventos");

        btnRegresar6.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnRegresar6.setText("Regresar");
        btnRegresar6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRegresar6MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(102, 102, 102)
                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 153, Short.MAX_VALUE)
                .addComponent(btnRegresar6, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(208, 208, 208))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnRegresar6, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel20)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jButton1.setBackground(new java.awt.Color(204, 255, 204));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setText("Eliminar Evento");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel22.setText("Lista de Eventos");

        jButton2.setBackground(new java.awt.Color(204, 255, 204));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setText("Editar Evento");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setBackground(new java.awt.Color(204, 255, 204));
        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton3.setText("Nuevo Evento");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        tabla_eventos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "codigo", "Lugar", "Representante", "Nombre", "Descripción", "Temática", "Tipo", "Fecha Inicio", "Fecha Fin"
            }
        ));
        jScrollPane1.setViewportView(tabla_eventos);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 838, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel22)
                    .addGap(225, 225, 225)
                    .addComponent(jButton3)
                    .addGap(28, 28, 28)
                    .addComponent(jButton2)
                    .addGap(33, 33, 33)
                    .addComponent(jButton1)
                    .addGap(0, 0, Short.MAX_VALUE))
                .addGroup(layout.createSequentialGroup()
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(175, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(113, 113, 113))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(20, 20, 20)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel22)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jButton2)
                        .addComponent(jButton1))
                    .addGap(0, 340, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegresar6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRegresar6MouseClicked
        Pag_Principal Pag_Principal = new Pag_Principal();
        Pag_Principal.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnRegresar6MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        int row = tabla_eventos.getSelectedRow();
            if (row == -1) { 
                JOptionPane.showMessageDialog(this, "Seleccione un evento"); return; 
            }
        int codigo = (int) tabla_eventos.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "¿Eliminar evento 'código' " + codigo + "?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (manager.delete(codigo)) {
                JOptionPane.showMessageDialog(this, " Evento eliminado ");
                loadTable();
            } else {
                JOptionPane.showMessageDialog(this, "Error al eliminar evento");
            }
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        int row = tabla_eventos.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Seleccione un evento"); return; }

        int id = (int) tabla_eventos.getValueAt(row, 0);

        Evento a = (Evento) manager.findById(id);  
        Evento edit = showEventForm(a);

        if (edit != null) {
                if (manager.update(id, edit)) {   // 🔥 ya no .toJSON()
                    JOptionPane.showMessageDialog(this, " Evento actualizado");
                    loadTable();
            } else {
                JOptionPane.showMessageDialog(this, "Error al actualizar el evento ");
            }
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        Evento nuevo = showEventForm(null);
            if (nuevo != null) {
                nuevo.setCodigo(manager.getNextId()); // asignar ID
            if (manager.add(nuevo)) {   // 🔥 ya no .toJSON()
                JOptionPane.showMessageDialog(this, " Evento creado");
                    loadTable();
            } else {
                JOptionPane.showMessageDialog(this, "Error al crear el evento");
            }
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Eventos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Eventos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Eventos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Eventos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Eventos().setVisible(true);
            }
        });
    }
    
    private Evento showEventForm(Evento evento) {
    JPanel panel = new JPanel(new GridLayout(9, 2, 10, 10)); // 9 campos, 2 columnas, con espacio entre celdas

    JTextField lugarField = new JTextField(20);
    JTextField representanteField = new JTextField(20);
    JTextField nombreField = new JTextField(20);
    JTextArea descripcionArea = new JTextArea(3, 20);
    JTextField tematicaField = new JTextField(20);
    JTextField tipoField = new JTextField(20);
    JTextField fechaInicioField = new JTextField(20);
    JTextField fechaFinField = new JTextField(20);
    JScrollPane descScroll = new JScrollPane(descripcionArea);

    // Si estamos editando, llenar los campos
    if (evento != null) {
        lugarField.setText(evento.getLugar());
        representanteField.setText(evento.getRepresentante());
        nombreField.setText(evento.getNombre());
        descripcionArea.setText(evento.getDescripcion());
        tematicaField.setText(evento.getTematica());
        tipoField.setText(evento.getTipo());
        fechaInicioField.setText(evento.getFecha_Inicio());
        fechaFinField.setText(evento.getFecha_Fin());
    }

    // Agregar campos al panel
    panel.add(new JLabel("Lugar:"));
    panel.add(lugarField);
    panel.add(new JLabel("Representante:"));
    panel.add(representanteField);
    panel.add(new JLabel("Nombre:"));
    panel.add(nombreField);
    panel.add(new JLabel("Descripción:"));
    panel.add(descScroll);  // JScrollPane para descripción larga
    panel.add(new JLabel("Temática:"));
    panel.add(tematicaField);
    panel.add(new JLabel("Tipo:"));
    panel.add(tipoField);
    panel.add(new JLabel("Fecha Inicio:"));
    panel.add(fechaInicioField);
    panel.add(new JLabel("Fecha Fin:"));
    panel.add(fechaFinField);

    int result = JOptionPane.showConfirmDialog(this, panel,
            evento != null ? "Editar Evento" : "Nuevo Evento",
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

    if (result == JOptionPane.OK_OPTION) {
        String lugar = lugarField.getText().trim();
        String representante = representanteField.getText().trim();
        String nombre = nombreField.getText().trim();
        String descripcion = descripcionArea.getText().trim();
        String tematica = tematicaField.getText().trim();
        String tipo = tipoField.getText().trim();
        String fechaInicio = fechaInicioField.getText().trim();
        String fechaFin = fechaFinField.getText().trim();

        if (lugar.isEmpty() || representante.isEmpty() || nombre.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ups, no puedes dejar campos obligatorios vacíos.");
            return null;
        }

        int codigo = evento != null ? evento.getCodigo() : 0;
        return new Evento(codigo, lugar, representante, nombre, descripcion, tematica, tipo, fechaInicio, fechaFin);
    }

    return null;
}


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnRegresar6;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabla_eventos;
    // End of variables declaration//GEN-END:variables
}
