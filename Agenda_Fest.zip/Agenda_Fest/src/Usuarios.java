import org.json.JSONObject;

public class Usuarios {
    
    private String nombres;
    private String apellidos;
    private String contrasena;

    // Constructor con todos los datos
    public Usuarios(String nombres, String apellidos, String contrasena) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.contrasena = contrasena;
    }

    // Getters y Setters
    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    // Convertir a JSON
    public JSONObject toJSON() {
        JSONObject o = new JSONObject();
        o.put("nombres", nombres);
        o.put("apellidos", apellidos);
        o.put("contrasena", contrasena);
        return o;
    }

    // Crear Usuario desde JSON
    public static Usuarios fromJSON(JSONObject o) {
        return new Usuarios(
            o.optString("nombres", ""),
            o.optString("apellidos", ""),
            o.optString("contrasena", "")
        );
    }
}
