import org.json.JSONObject;

public class Ticket {
    private int codigo;
    private String tipo;
    private String precio;
    private String evento;
    
    // 🔹 Constructor con código (para cargar/actualizar)
    public Ticket(int codigo, String tipo, String precio, String evento) {
        this.codigo = codigo;
        this.precio = precio;
        this.tipo= tipo;
        this.evento = evento;
    }
    
    // 🔹 Constructor sin código (para nuevos Tickets)
    public Ticket(String tipo, String precio, String evento) {
        this.precio = precio;
        this.tipo= tipo;
        this.evento = evento;
    }
    
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String getEvento() {
        return evento;
    }

    public void setEvento(String evento) {
        this.evento = evento;
    }

    
    public JSONObject toJSON() {
        JSONObject o = new JSONObject();
        o.put("codigo", codigo);
        o.put("tipo", tipo);
        o.put("precio", precio);
        o.put("evento", evento);
        return o;
    }

    // 🔥 Crear desde JSON
    public static Ticket fromJSON(JSONObject o) {
        return new Ticket(
            o.optInt("codigo", 0),
            o.optString("tipo", ""),
            o.optString("precio", ""),
            o.optString("evento", "")
        );
    }
}
