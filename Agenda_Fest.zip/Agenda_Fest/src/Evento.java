import org.json.JSONObject;

public class Evento {
    private int codigo;
    private String lugar;
    private String representante;
    private String nombre;
    private String descripcion;        // manejada como texto por simplicidad
    private String tematica;
    private String tipo;
    private String fecha_inicio;
    private String fecha_fin;

    // 🔹 Constructor con código (para cargar/actualizar)
    public Evento(int codigo, String lugar, String representante, String nombre, String descripcion, String tematica, String tipo, String fecha_inicio, String fecha_fin) {
        this.codigo = codigo;
        this.lugar = lugar;
        this.representante = representante;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.tematica = tematica;
        this.tipo= tipo;
        this.fecha_inicio = fecha_inicio;
        this.fecha_fin = fecha_fin;
    }

        // 🔹 Constructor sin código (para nuevos eventos)
    public Evento(String lugar, String representante, String nombre, String descripcion, String tematica, String tipo, String fecha_inicio, String fecha_fin) {
        this.lugar = lugar;
        this.representante = representante;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.tematica = tematica;
        this.tipo= tipo;
        this.fecha_inicio = fecha_inicio;
        this.fecha_fin = fecha_fin;
    }
    
    // Getters
    public int getCodigo() { 
        return codigo; 
    }
    public String getLugar() { return lugar; }
    public String getRepresentante() { return representante; }
    public String getNombre() { return nombre; }
    public String getDescripcion() { return descripcion; }
    public String getTematica() { return tematica; }
    public String getTipo() { return tipo; }
    public String getFecha_Inicio() { return fecha_inicio; }
    public String getFecha_Fin() { return fecha_fin; }
    

    // Setters
    public void setCodigo(int codigo) { this.codigo = codigo; }
    public void setLugar(String lugar) { this.lugar = lugar; }
    public void setRepresentante(String representante) { this.representante = representante; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public void setTematica(String tematica) { this.tematica = tematica; }
    public void getTipo(String tipo) { this.tipo = tipo; }
    public void setFecha_Inicio(String fecha_inicio) { this.fecha_inicio = fecha_inicio; }
    public void setFecha_Fin(String fecha_fin) { this.fecha_fin = fecha_fin; }

    // 🔥 Convertir a JSON
    public JSONObject toJSON() {
        JSONObject o = new JSONObject();
        o.put("codigo", codigo);
        o.put("lugar", lugar);
        o.put("representante", representante);
        o.put("nombre", nombre);
        o.put("descripcion", descripcion);
        o.put("tematica", tematica);
        o.put("tipo", tipo);
        o.put("fecha_inicio", fecha_inicio);
        o.put("fecha_fin", fecha_fin);
        return o;
    }

    // 🔥 Crear desde JSON
    public static Evento fromJSON(JSONObject o) {
        return new Evento(
            o.optInt("codigo", 0),
            o.optString("lugar", ""),
            o.optString("representante", ""),
            o.optString("nombre", ""),
            o.optString("descripcion", ""),
            o.optString("tematica", ""),
            o.optString("tipo", ""),
            o.optString("fecha_inicio", ""),
            o.optString("fecha_fin", "")
        );
    }
}

