import java.awt.Component;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import org.json.JSONArray;
import org.json.JSONObject;


public class Patrocinadores extends javax.swing.JFrame {

    private JSONDataManager manager;
    
    
    public Patrocinadores() {
        initComponents();
         manager = new JSONDataManager<>("patrocinador.json", Patrocinador.class);
        loadTable();     
        ajustarColumnas(tablapatrocinador);
    }

    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablapatrocinador = new javax.swing.JTable();
        jLabel11 = new javax.swing.JLabel();
        btnNewpatrocinador = new javax.swing.JButton();
        btnEditpatrocinador = new javax.swing.JButton();
        btnDelpatrocinador = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        btnRegresar1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));

        tablapatrocinador.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Código", "Nombre", "Tipo", "Teléfono"
            }
        ));
        jScrollPane1.setViewportView(tablapatrocinador);

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel11.setText("Lista de Patrocinadores");

        btnNewpatrocinador.setBackground(new java.awt.Color(204, 255, 204));
        btnNewpatrocinador.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnNewpatrocinador.setText("Nuevo Patrocinador");
        btnNewpatrocinador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewpatrocinadorActionPerformed(evt);
            }
        });

        btnEditpatrocinador.setBackground(new java.awt.Color(204, 255, 204));
        btnEditpatrocinador.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnEditpatrocinador.setText("Editar Patrocinador");
        btnEditpatrocinador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditpatrocinadorActionPerformed(evt);
            }
        });

        btnDelpatrocinador.setBackground(new java.awt.Color(204, 255, 204));
        btnDelpatrocinador.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnDelpatrocinador.setText("Eliminar Patrocinador");
        btnDelpatrocinador.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelpatrocinadorActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 815, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(19, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGap(43, 43, 43)
                        .addComponent(btnNewpatrocinador)
                        .addGap(28, 28, 28)
                        .addComponent(btnEditpatrocinador)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnDelpatrocinador)
                        .addGap(15, 15, 15))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnEditpatrocinador)
                        .addComponent(btnNewpatrocinador, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnDelpatrocinador)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(249, 140, 32));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("AgendaFest 2025");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Fiestas Novembrinas Cartagena de Indias ");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Gestión de Patrocinadores");

        btnRegresar1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btnRegresar1.setText("Regresar");
        btnRegresar1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnRegresar1MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 155, Short.MAX_VALUE)
                .addComponent(btnRegresar1, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(286, 286, 286)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(btnRegresar1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(37, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(10, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegresar1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnRegresar1MouseClicked
        Pag_Principal Pag_Principal = new Pag_Principal();
        Pag_Principal.setVisible(true);
        Pag_Principal.pack();
        Pag_Principal.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_btnRegresar1MouseClicked

    private void btnNewpatrocinadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewpatrocinadorActionPerformed
        Patrocinador nuevo = showPatrocinadorForm(null);
        if (nuevo != null) {
            nuevo.setCodigo(manager.getNextId());
            if (manager.add(nuevo)) {
                JOptionPane.showMessageDialog(this, "Patrocinador creado");
                loadTable();
            } else {
                JOptionPane.showMessageDialog(this, "Error al crear el patrocinador");
            }
        }
    }//GEN-LAST:event_btnNewpatrocinadorActionPerformed

    private void btnEditpatrocinadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditpatrocinadorActionPerformed
        int row = tablapatrocinador.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un patrocinador");
            return;
        }

        int id = (int) tablapatrocinador.getValueAt(row, 0);
        Patrocinador p = (Patrocinador) manager.findById(id);
        Patrocinador editado = showPatrocinadorForm(p);

        if (editado != null) {
            if (manager.update(id, editado)) {
                JOptionPane.showMessageDialog(this, " Patrocinador actualizado");
                loadTable();
            } else {
                JOptionPane.showMessageDialog(this, "Error al actualizar");
            }
        }
    }//GEN-LAST:event_btnEditpatrocinadorActionPerformed

    private void btnDelpatrocinadorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelpatrocinadorActionPerformed
        int row = tablapatrocinador.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Seleccione un patrocinador");
            return;
        }

        int id = (int) tablapatrocinador.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "¿Eliminar patrocinador con ID " + id + "?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (manager.delete(id)) {
                JOptionPane.showMessageDialog(this, "Patrocinador eliminado");
                loadTable();
            } else {
                JOptionPane.showMessageDialog(this, "Error al eliminar el patrocinador");
            }
        }
    }//GEN-LAST:event_btnDelpatrocinadorActionPerformed

     private void loadTable() {
        String[] cols = {"Codigo", "Nombre", "Tipo", "Teléfono"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };

        JSONArray arr = manager.findAll();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            Object[] row = {
                o.optInt("codigo", 0),
                o.optString("nombre", ""),
                o.optString("tipo", ""),
                o.optString("telefono", "")
                
            };
            model.addRow(row);
        }

        tablapatrocinador.setModel(model);
        ajustarColumnas(tablapatrocinador);
     }
      public void ajustarColumnas(JTable table) {
        for (int column = 0; column < table.getColumnCount(); column++) {
            TableColumn col = table.getColumnModel().getColumn(column);
            int width = 50; // ancho mínimo
            for (int row = 0; row < table.getRowCount(); row++) {
                TableCellRenderer renderer = table.getCellRenderer(row, column);
                Component comp = table.prepareRenderer(renderer, row, column);
                width = Math.max(comp.getPreferredSize().width + 10, width);
            }
            col.setPreferredWidth(width);
        }
    }
      private Patrocinador showPatrocinadorForm(Patrocinador p) {
    JPanel panel = new JPanel(new GridLayout(4, 2, 10, 10)); // 4 campos

    JTextField nombreField = new JTextField(20);
    JTextField tipoField = new JTextField(20);
    JTextField telefonoField = new JTextField(20);

    if (p != null) {
        nombreField.setText(p.getNombre());
        tipoField.setText(p.getTipo());
        telefonoField.setText(p.getTelefono());
    }

    panel.add(new JLabel("Nombre:"));
    panel.add(nombreField);
    panel.add(new JLabel("Tipo:"));
    panel.add(tipoField);
    panel.add(new JLabel("Teléfono:"));
    panel.add(telefonoField);

    int result = JOptionPane.showConfirmDialog(this, panel,
        p != null ? "Editar Patrocinador" : "Nuevo Patrocinador",
        JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

    if (result == JOptionPane.OK_OPTION) {
        String nombre = nombreField.getText().trim();
        String tipo = tipoField.getText().trim();
        String telefono = telefonoField.getText().trim();

        if (nombre.isEmpty() || tipo.isEmpty() || telefono.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ningún campo puede estar vacío.");
            return null;
        }

        int codigo = p != null ? p.getCodigo() : 0;
        return new Patrocinador(codigo, nombre, tipo, telefono);
    }
    return null;
}

    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Patrocinadores().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnDelpatrocinador;
    private javax.swing.JButton btnEditpatrocinador;
    private javax.swing.JButton btnNewpatrocinador;
    private javax.swing.JButton btnRegresar1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablapatrocinador;
    // End of variables declaration//GEN-END:variables
}
