import java.awt.List;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.ArrayList;
import org.json.*;

public class JSONDataManager<T> {
    private final Path path;
    private final Class<T> typeClass;

    public JSONDataManager(String filePath, Class<T> typeClass) {
        this.path = Paths.get(filePath);
        this.typeClass = typeClass;
        createFileIfNotExists();
    }

    // Crear archivo si no existe
    private void createFileIfNotExists() {
        try {
            if (Files.notExists(path)) {
                if (path.getParent() != null) Files.createDirectories(path.getParent());
                Files.write(path, "[]".getBytes(StandardCharsets.UTF_8));
            }
        } catch (IOException e) {
            throw new RuntimeException("Error creando archivo JSON: " + e.getMessage(), e);
        }
    }

    // Leer JSON del archivo
    private synchronized JSONArray readData() {
        try {
            String content = Files.readString(path, StandardCharsets.UTF_8).trim();
            if (content.isEmpty()) content = "[]";
            return new JSONArray(content);
        } catch (IOException | JSONException e) {
            e.printStackTrace();
            return new JSONArray();
        }
    }

    // Guardar JSON al archivo
    private synchronized boolean writeData(JSONArray data) {
        try {
            Path tmp = path.resolveSibling(path.getFileName().toString() + ".tmp");
            Files.writeString(tmp, data.toString(4), StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
            Files.move(tmp, path, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Obtener siguiente ID incremental
    public synchronized int getNextId() {
        JSONArray arr = readData();
        int max = 0;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o != null) {
                int id = o.optInt("id", 0);
                if (id > max) max = id;
            }
        }
        return max + 1;
    }

    // ====================== CRUD GENERALES ======================

    // Crear
    public synchronized boolean add(T obj) {
        try {
            JSONArray arr = readData();
            JSONObject jsonObj = convertToJSON(obj);
            if (!jsonObj.has("id")) jsonObj.put("id", getNextId());
            arr.put(jsonObj);
            return writeData(arr);
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Buscar por ID
    public synchronized T findById(int id) {
        JSONArray arr = readData();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o != null && o.optInt("id", -1) == id) {
                return convertFromJSON(o);
            }
        }
        return null;
    }

    // Actualizar
    public synchronized boolean update(int id, T newObj) {
        JSONArray arr = readData();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o != null && o.optInt("id", -1) == id) {
                try {
                    JSONObject newJsonObj = convertToJSON(newObj);
                    newJsonObj.put("id", id);
                    arr.put(i, newJsonObj);
                    return writeData(arr);
                } catch (JSONException e) {
                    e.printStackTrace();
                    return false;
                }
            }
        }
        return false;
    }

    // Eliminar
    public synchronized boolean delete(int id) {
        JSONArray arr = readData();
        JSONArray out = new JSONArray();
        boolean removed = false;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o != null && o.optInt("id", -1) == id) {
                removed = true;
                continue;
            }
            out.put(o);
        }
        if (removed) return writeData(out);
        return false;                    
    }

    // Listar todos
    public synchronized JSONArray findAll() {
        return readData();
    }

    // ====================== CONVERSIÓN ======================

    // Métodos de conversión
    private JSONObject convertToJSON(T obj) {
        if (obj instanceof Artista) {
            return ((Artista) obj).toJSON();
        } else if (obj instanceof Evento) {
            return ((Evento) obj).toJSON();
        } else if (obj instanceof Ticket) {
            return ((Ticket) obj).toJSON();
        } else if (obj instanceof Lugar) {
            return ((Lugar) obj).toJSON();
        }else if (obj instanceof Representante) {
            return ((Representante) obj).toJSON();
        }else if (obj instanceof Patrocinador) {
            return ((Patrocinador) obj).toJSON();
        }else if (obj instanceof Afiche) {
            return ((Afiche) obj).toJSON();
        }
        throw new IllegalArgumentException("Tipo no soportado: " + obj.getClass());
    }


@SuppressWarnings("unchecked")
    private T convertFromJSON(JSONObject jsonObj) {
        if (typeClass == Artista.class) {
            return (T) Artista.fromJSON(jsonObj);
        } else if (typeClass == Evento.class) {
            return (T) Evento.fromJSON(jsonObj);
        } else if (typeClass == Ticket.class) {
            return (T) Ticket.fromJSON(jsonObj);
        }else if (typeClass == Lugar.class){
            return (T) Lugar.fromJSON(jsonObj);
        }else if (typeClass == Representante.class){
            return (T) Representante.fromJSON(jsonObj);
        }else if (typeClass == Patrocinador.class){
            return (T) Patrocinador.fromJSON(jsonObj);
        }else if (typeClass == Afiche.class){
            return (T) Afiche.fromJSON(jsonObj);
        }
        throw new IllegalArgumentException("Tipo no soportado: " + typeClass);
    }
}
